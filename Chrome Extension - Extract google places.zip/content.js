// Google Places Extractor Content Script
class GooglePlacesExtractor {
  constructor() {
    this.isScrapingActive = false;
    this.scrapedData = [];
    this.init();
  }

  async init() {
    await this.restoreState();
    this.createScrapingUI();
    this.listenForMessages();
    
    // If scraping was active, continue scraping on this page
    if (this.isScrapingActive) {
      setTimeout(() => {
        this.scrapeCurrentPage();
        this.setupPageChangeListener();
      }, 1000);
    }
  }

  async restoreState() {
    try {
      const result = await chrome.storage.local.get(['scrapedData', 'isScrapingActive']);
      this.scrapedData = result.scrapedData || [];
      this.isScrapingActive = result.isScrapingActive || false;
    } catch (error) {
      console.log('Error restoring state:', error);
      this.scrapedData = [];
      this.isScrapingActive = false;
    }
  }

  async saveState() {
    try {
      await chrome.storage.local.set({
        scrapedData: this.scrapedData,
        isScrapingActive: this.isScrapingActive
      });
    } catch (error) {
      console.log('Error saving state:', error);
    }
  }

  createScrapingUI() {
    // Remove existing panel if it exists
    const existingPanel = document.getElementById('cricket-scraper-panel');
    if (existingPanel) {
      existingPanel.remove();
    }

    // Create floating scraper controls
    const scrapingPanel = document.createElement('div');
    scrapingPanel.id = 'cricket-scraper-panel';
    scrapingPanel.innerHTML = `
      <div style="position: fixed; top: 20px; right: 20px; z-index: 10000; background: #fff; border: 2px solid #4285f4; border-radius: 8px; padding: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); font-family: Arial, sans-serif; min-width: 250px;">
        <h3 style="margin: 0 0 10px 0; color: #333; font-size: 16px;">Google Places Extractor</h3>
        <div style="margin-bottom: 10px;">
          <button id="start-scraping" style="background: #4285f4; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-right: 8px;">Start Scraping</button>
          <button id="stop-scraping" style="background: #ea4335; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Stop</button>
        </div>
        <div style="margin-bottom: 10px;">
          <button id="export-data" style="background: #34a853; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-right: 8px;">Export CSV</button>
          <button id="clear-data" style="background: #fbbc04; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Clear Data</button>
        </div>
        <div id="scraping-status" style="font-size: 12px; color: #666;">Ready to scrape</div>
        <div id="data-count" style="font-size: 12px; color: #666; margin-top: 5px;">Items scraped: 0</div>
      </div>
    `;
    document.body.appendChild(scrapingPanel);

    // Add event listeners
    document.getElementById('start-scraping').addEventListener('click', () => this.startScraping());
    document.getElementById('stop-scraping').addEventListener('click', () => this.stopScraping());
    document.getElementById('export-data').addEventListener('click', () => this.exportData());
    document.getElementById('clear-data').addEventListener('click', () => this.clearData());

    // Update UI based on current state
    this.updateUIState();
  }

  updateUIState() {
    const startButton = document.getElementById('start-scraping');
    const stopButton = document.getElementById('stop-scraping');
    const statusElement = document.getElementById('scraping-status');

    if (this.isScrapingActive) {
      startButton.disabled = true;
      stopButton.disabled = false;
      statusElement.textContent = 'Scraping in progress...';
    } else {
      startButton.disabled = false;
      stopButton.disabled = true;
      statusElement.textContent = 'Ready to scrape';
    }

    this.updateDataCount();
  }

  async startScraping() {
    this.isScrapingActive = true;
    await this.saveState();
    
    document.getElementById('start-scraping').disabled = true;
    document.getElementById('stop-scraping').disabled = false;
    document.getElementById('scraping-status').textContent = 'Scraping in progress...';
    
    this.scrapeCurrentPage();
    this.setupPageChangeListener();
  }

  async stopScraping() {
    this.isScrapingActive = false;
    await this.saveState();
    
    document.getElementById('start-scraping').disabled = false;
    document.getElementById('stop-scraping').disabled = true;
    document.getElementById('scraping-status').textContent = 'Scraping stopped';
  }

  async scrapeCurrentPage() {
    if (!this.isScrapingActive) {
      console.log('Scraping not active, skipping...');
      return;
    }

    console.log('=== Starting scrapeCurrentPage ===');
    const places = this.extractPlacesData();
    
    if (places.length === 0) {
      console.log('❌ No places found on this page!');
      console.log('Page might not be loaded yet or selectors need updating');
      return;
    }
    
    console.log(`Found ${places.length} places on this page`);
    
    // Filter out duplicates based on place ID (data-cid) or fallback to name and address
    const newPlaces = places.filter(newPlace => {
      return !this.scrapedData.some(existingPlace => {
        // Primary check: use ID if both places have it
        if (existingPlace.id && newPlace.id) {
          const isDuplicate = existingPlace.id === newPlace.id;
          if (isDuplicate) {
            console.log(`Duplicate found (ID): "${newPlace.name}" (${newPlace.id})`);
          }
          return isDuplicate;
        }
        // Fallback: use name and address if ID is not available
        const isDuplicate = existingPlace.name === newPlace.name && 
               existingPlace.address === newPlace.address;
        if (isDuplicate) {
          console.log(`Duplicate found (name+address): "${newPlace.name}"`);
        }
        return isDuplicate;
      });
    });

    console.log(`After filtering duplicates: ${newPlaces.length} new places`);

    this.scrapedData.push(...newPlaces);
    this.updateDataCount();
    
    // Save to storage
    await this.saveState();
    
    console.log(`✅ Scraped ${newPlaces.length} new places from this page. Total: ${this.scrapedData.length}`);
    
    // Log the search keyword being used
    if (newPlaces.length > 0) {
      const searchKeyword = newPlaces[0].searchKeyword;
      console.log(`Search keyword: "${searchKeyword}"`);
    }
    
    // Debug: Log places with missing addresses or IDs
    newPlaces.forEach((place, index) => {
      console.log(`Place ${index + 1}: "${place.name}"`);
      if (!place.address) {
        console.log(`  ⚠️ Missing address`);
      } else {
        console.log(`  📍 Address: ${place.address}`);
      }
      if (!place.id) {
        console.log(`  ⚠️ Missing ID (data-cid)`);
      } else {
        console.log(`  🆔 ID: ${place.id}`);
      }
    });
    
    console.log('=== End scrapeCurrentPage ===');
  }

  extractPlacesData() {
    const places = [];
    
    console.log('Starting place extraction...');
    console.log('Current URL:', window.location.href);
    
    // Try multiple selectors for different Google Places layouts
    const placeSelectors = [
      '[data-result-index]',
      '.VkpGBb',
      '.Nv2PK', 
      '.tF2Cxc',
      '.g',
      '.rllt__link',
      '.yuRUbf',
      '.MjjYud',
      '.kvH3mc',
      '.uMdZh'
    ];

    let placeElements = [];
    let usedSelector = '';
    
    for (const selector of placeSelectors) {
      placeElements = document.querySelectorAll(selector);
      console.log(`Selector "${selector}" found ${placeElements.length} elements`);
      if (placeElements.length > 0) {
        usedSelector = selector;
        break;
      }
    }

    if (placeElements.length === 0) {
      console.log('No place elements found with any selector!');
      console.log('Available elements on page:');
      
      // Log some common elements to help debug
      const commonSelectors = ['div', '.g', '[data-cid]', 'h3', 'a'];
      commonSelectors.forEach(sel => {
        const elements = document.querySelectorAll(sel);
        console.log(`  ${sel}: ${elements.length} elements`);
      });
      
      return places;
    }

    console.log(`Using selector "${usedSelector}" - found ${placeElements.length} elements`);

    placeElements.forEach((element, index) => {
      try {
        console.log(`Processing element ${index + 1}/${placeElements.length}`);
        const placeData = this.extractPlaceInfo(element);
        if (placeData && placeData.name) {
          console.log(`Successfully extracted: "${placeData.name}"`);
          places.push(placeData);
        } else {
          console.log(`Failed to extract data from element ${index + 1} - no name found`);
          console.log('Element HTML:', element.outerHTML.substring(0, 200) + '...');
        }
      } catch (error) {
        console.log(`Error extracting place data from element ${index + 1}:`, error);
        console.log('Element HTML:', element.outerHTML.substring(0, 200) + '...');
      }
    });

    console.log(`Total places extracted: ${places.length}`);
    return places;
  }

  extractPlaceInfo(element) {
    const placeData = {
      id: '',
      name: '',
      address: '',
      website: '',
      phone: '',
      email: '',
      rating: '',
      reviewCount: '',
      businessType: '',
      closureStatus: '',
      searchKeyword: this.extractSearchKeyword(),
      googleLocation: window.location.href,
      scrapedAt: new Date().toISOString()
    };

    // Extract name and ID from anchor tag
    const nameSelectors = [
      'h3',
      '.DKV0Md',
      '.LC20lb',
      '.OSrXXb',
      '.BNeawe.vvjwJb.AP7Wnd',
      '.yuRUbf h3',
      '.MjjYud h3',
      '.kvH3mc h3',
      'a h3',
      '[data-cid] h3'
    ];
    
    console.log('Trying to extract name...');
    
    for (const selector of nameSelectors) {
      const nameElement = element.querySelector(selector);
      if (nameElement) {
        let rawName = nameElement.textContent.trim();
        
        // Clean the name by removing rating and review count
        // Remove patterns like "4.7(47)" or "4.7 (47)"
        rawName = rawName.replace(/\d+\.\d+\s*\(\d+\)/g, '').trim();
        // Remove any remaining rating patterns
        rawName = rawName.replace(/\d+\.\d+/g, '').trim();
        // Remove extra spaces
        rawName = rawName.replace(/\s+/g, ' ').trim();
        
        if (rawName && rawName.length > 0) {
          placeData.name = rawName;
          console.log(`Found name "${placeData.name}" using selector "${selector}"`);
          
          // Look for the anchor tag with data-cid in the name element or its parent
          const anchorElement = nameElement.closest('a') || nameElement.querySelector('a');
          if (anchorElement && anchorElement.getAttribute('data-cid')) {
            placeData.id = anchorElement.getAttribute('data-cid');
            console.log(`Found ID: ${placeData.id}`);
          }
          break;
        }
      }
    }
    
    // Fallback: Look for any anchor with data-cid in the element
    if (!placeData.id) {
      const anchorWithCid = element.querySelector('a[data-cid]');
      if (anchorWithCid) {
        placeData.id = anchorWithCid.getAttribute('data-cid');
        console.log(`Found ID from fallback: ${placeData.id}`);
        // If we didn't get the name yet, try to get it from this anchor
        if (!placeData.name) {
          placeData.name = anchorWithCid.textContent.trim();
          console.log(`Found name from anchor: ${placeData.name}`);
        }
      }
    }
    
    if (!placeData.name) {
      console.log('Could not find name with any selector');
      console.log('Available h3 elements:', element.querySelectorAll('h3').length);
      console.log('Available anchors:', element.querySelectorAll('a').length);
      console.log('Available data-cid anchors:', element.querySelectorAll('a[data-cid]').length);
    }

    // Extract address and phone using the structured approach
    // Based on the pattern:
    // Line 1: Name
    // Line 2: Rating(count) · Business type
    // Line 3: Address · Phone
    // Line 4: Open/Close status
    
    const elementText = element.textContent;
    // Try multiple ways to split the text into lines
    let lines = elementText.split('\n').map(line => line.trim()).filter(line => line);
    
    // If no proper lines found, try splitting by common patterns
    if (lines.length <= 1) {
      // Try splitting by rating pattern, address pattern, and opening hours
      const patterns = [
        /(\d+\.\d+\(\d+\)\s*·[^·]+)/g,  // Rating pattern
        /([^·]+·\s*\d{6}\s*\d{5})/g,    // Address phone pattern
        /(Open\s*⋅[^"]+)/g              // Opening hours pattern
      ];
      
      let tempText = elementText;
      for (const pattern of patterns) {
        tempText = tempText.replace(pattern, '\n$1\n');
      }
      lines = tempText.split('\n').map(line => line.trim()).filter(line => line);
    }
    
    console.log('Lines in element:', lines);
    console.log('Element text:', elementText);
    
    // Find the address line - it should NOT contain rating pattern and should be after the rating line
    let foundRatingLine = false;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      
      // Skip empty lines or lines that are clearly not address
      if (!line || line.startsWith('"') || line.length < 3) {
        continue;
      }
      
      // Check if this is the rating line (has rating pattern with parentheses)
      if (line.match(/\d+\.\d+\s*\(\d+\)/)) {
        foundRatingLine = true;
        continue;
      }
      
      // Look for address line - should come after rating line and not contain rating pattern
      if (foundRatingLine && !line.match(/\d+\.\d+\s*\(\d+\)/)) {
        // Check if line contains address patterns
        const isLikelyAddress = (
          // Plus code format like "9JW3+7XR"
          /^[0-9A-Z]{4}\+[0-9A-Z]{2,3}/.test(line) ||
          // Traditional address with location names
          line.includes('Hyderabad') || 
          line.includes('Telangana') || 
          line.includes('Road') || 
          line.includes('Street') || 
          line.includes('Nagar') || 
          line.includes('Colony') ||
          line.includes('Area') ||
          // Address with numbers and letters (but not opening hours)
          (/\d+/.test(line) && /[A-Za-z]/.test(line) && line.length > 5 && !line.toLowerCase().includes('open') && !line.toLowerCase().includes('close'))
        );
        
        if (isLikelyAddress) {
          // Check if it has phone pattern with · separator
          if (line.includes('·')) {
            const parts = line.split('·').map(part => part.trim());
            if (parts.length >= 2) {
              const addressPart = parts[0].trim();
              const phonePart = parts[1].trim();
              
              // Check if the second part looks like a phone number
              const phonePattern = /^\d{3,4}[\s-]?\d{2,3}[\s-]?\d{2,3}[\s-]?\d{2,3}$/;
              if (phonePattern.test(phonePart)) {
                placeData.address = addressPart;
                placeData.phone = phonePart;
                console.log(`Found address: "${addressPart}" and phone: "${phonePart}"`);
                break;
              }
            }
          } else {
            // Address without phone separator
            placeData.address = line;
            console.log(`Found address: "${line}"`);
            
            // Look for phone in the same line
            const phoneMatch = line.match(/(\d{3,4}[\s-]?\d{2,3}[\s-]?\d{2,3}[\s-]?\d{2,3})/);
            if (phoneMatch && !placeData.phone) {
              placeData.phone = phoneMatch[0];
              // Remove phone from address
              placeData.address = line.replace(phoneMatch[0], '').trim();
              console.log(`Found phone in address: "${placeData.phone}"`);
            }
            break;
          }
        }
      }
    }
    
    // If still no phone found, look for phone patterns in all lines
    if (!placeData.phone) {
      for (const line of lines) {
        const phoneMatch = line.match(/(\d{3,4}[\s-]?\d{2,3}[\s-]?\d{2,3}[\s-]?\d{2,3})/);
        if (phoneMatch) {
          placeData.phone = phoneMatch[0];
          console.log(`Found phone: "${placeData.phone}"`);
          break;
        }
      }
    }

    // Additional fallback for address extraction if structured approach failed
    if (!placeData.address) {
      console.log('Structured address extraction failed, trying fallback...');
      
      // Look for address patterns in all lines, but be more selective
      for (const line of lines) {
        // Skip lines that are clearly not addresses
        if (line.includes('(') && line.includes(')') || // Rating lines
            line.toLowerCase().includes('open') || 
            line.toLowerCase().includes('closed') || 
            line.toLowerCase().includes('am') || 
            line.toLowerCase().includes('pm') ||
            line.startsWith('"') ||
            line.includes('Website') ||
            line.includes('Directions') ||
            line.length < 3) {
          continue;
        }
        
        // Check for address indicators
        const hasAddressIndicators = (
          // Plus code format like "9JW3+7XR"
          /^[0-9A-Z]{4}\+[0-9A-Z]{2,3}/.test(line) ||
          // Traditional address with location names
          line.includes('Hyderabad') || 
          line.includes('Telangana') || 
          line.includes('Road') || 
          line.includes('Street') || 
          line.includes('Nagar') || 
          line.includes('Colony') ||
          line.includes('Area') ||
          line.includes('Secunderabad') ||
          // Address with numbers and letters (but reasonable length)
          (/\d+/.test(line) && /[A-Za-z]/.test(line) && line.length > 5 && line.length < 100)
        );
        
        if (hasAddressIndicators) {
          // Clean up the address by removing phone if present
          let cleanAddress = line;
          const phoneMatch = line.match(/(\d{3,4}[\s-]?\d{2,3}[\s-]?\d{2,3}[\s-]?\d{2,3})/);
          if (phoneMatch) {
            cleanAddress = line.replace(phoneMatch[0], '').replace(/·/g, '').trim();
            if (!placeData.phone) {
              placeData.phone = phoneMatch[0];
              console.log(`Found phone in fallback: "${placeData.phone}"`);
            }
          }
          
          // Remove any remaining separators
          cleanAddress = cleanAddress.replace(/^[·\s]+|[·\s]+$/g, '').trim();
          
          if (cleanAddress && cleanAddress.length > 0) {
            placeData.address = cleanAddress;
            console.log(`Found address via fallback: "${cleanAddress}"`);
            break;
          }
        }
      }
    }

    // Extract website
    const linkElement = element.querySelector('a[href*="http"]');
    if (linkElement) {
      placeData.website = linkElement.href;
    }

    // Phone extraction is handled in address section

    // Extract email
    const emailPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
    const elementTextContent = element.textContent;
    const emailMatch = elementTextContent.match(emailPattern);
    if (emailMatch) {
      placeData.email = emailMatch[0];
    }

    // Extract rating, review count, and business type from the structured lines
    // Look for the rating line: "4.5(48) · Cricket ground"
    for (const line of lines) {
      // Check if this line has the rating pattern with parentheses and business type
      if (line.includes('(') && line.includes(')') && line.includes('·')) {
        const ratingMatch = line.match(/^(\d+\.?\d*)/);
        if (ratingMatch) {
          placeData.rating = ratingMatch[1];
          console.log(`Found rating: "${placeData.rating}"`);
        }
        
        const reviewCountMatch = line.match(/\(([0-9,]+)\)/);
        if (reviewCountMatch) {
          placeData.reviewCount = reviewCountMatch[1].replace(/,/g, '');
          console.log(`Found review count: "${placeData.reviewCount}"`);
        }
        
        // Extract business type after the rating and review count
        const businessTypeMatch = line.match(/\([0-9,]+\)\s*·\s*(.+)/);
        if (businessTypeMatch) {
          placeData.businessType = businessTypeMatch[1].trim();
          console.log(`Found business type: "${placeData.businessType}"`);
        }
        break;
      }
    }
    
    // Fallback: Try the original selectors if line parsing didn't work
    if (!placeData.rating) {
      const ratingSelectors = ['.Aq14fc', '.yi40Hd', '.MW4etd', '.UY7F9'];
      let ratingText = '';
      
      for (const selector of ratingSelectors) {
        const ratingElement = element.querySelector(selector);
        if (ratingElement) {
          ratingText = ratingElement.textContent.trim();
          break;
        }
      }

      // Parse rating, review count, and business type from text like "4.5(178) · Cricket club"
      if (ratingText) {
        const ratingMatch = ratingText.match(/^(\d+\.?\d*)/);
        if (ratingMatch) {
          placeData.rating = ratingMatch[1];
        }
        
        const reviewCountMatch = ratingText.match(/\(([0-9,]+)\)/);
        if (reviewCountMatch) {
          placeData.reviewCount = reviewCountMatch[1].replace(/,/g, '');
        }
        
        // Extract business type after the rating and review count
        const businessTypeMatch = ratingText.match(/\([0-9,]+\)\s*·\s*(.+)/);
        if (businessTypeMatch) {
          placeData.businessType = businessTypeMatch[1].trim();
        }
      }
    }

    // Also try to find review count in other elements
    if (!placeData.reviewCount) {
      const reviewSelectors = ['.RGd2Bf', '.hqzQac', '.Y0A0hc'];
      for (const selector of reviewSelectors) {
        const reviewElement = element.querySelector(selector);
        if (reviewElement) {
          const reviewText = reviewElement.textContent.trim();
          const reviewMatch = reviewText.match(/\(([0-9,]+)/);
          if (reviewMatch) {
            placeData.reviewCount = reviewMatch[1].replace(/,/g, '');
            break;
          }
        }
      }
    }

    // Extract closure/opening status from the structured lines
    // Look for lines with "Open" or "Closed" status
    for (const line of lines) {
      const lowerLine = line.toLowerCase();
      
      // Skip lines that are clearly not status lines
      if (line.includes('(') || line.includes('"') || line.includes('Website') || line.includes('Directions') || line.length > 100) {
        continue;
      }
      
      // Check for opening hours pattern like "Open ⋅ Closes 10 pm"
      if (lowerLine.includes('open') && (lowerLine.includes('⋅') || lowerLine.includes('closes'))) {
        // Make sure this is just the status line, not mixed with other content
        if (line.length < 50 && !line.includes('(') && !line.includes('"')) {
          placeData.closureStatus = line; // Store the full opening hours info
          console.log(`Found opening status: "${line}"`);
          break;
        }
      }
      
      // Check for closure status
      if (lowerLine.includes('permanently closed')) {
        placeData.closureStatus = 'Permanently Closed';
        console.log(`Found closure status: "Permanently Closed"`);
        break;
      } else if (lowerLine.includes('temporarily closed')) {
        placeData.closureStatus = 'Temporarily Closed';
        console.log(`Found closure status: "Temporarily Closed"`);
        break;
      } else if (lowerLine.includes('closed') && !lowerLine.includes('open') && line.length < 30) {
        placeData.closureStatus = 'Closed';
        console.log(`Found closure status: "Closed"`);
        break;
      }
    }
    
    // If no clear status found, look for specific opening hours patterns
    if (!placeData.closureStatus) {
      for (const line of lines) {
        // Look for specific opening hours patterns
        if (line.match(/^(Open|Closed)\s*⋅/i) || line.match(/^(Open|Closed)\s+(until|at|⋅)/i)) {
          placeData.closureStatus = line;
          console.log(`Found status pattern: "${line}"`);
          break;
        }
      }
    }
    
    // Fallback: Check the full text for closure keywords only if no status found
    if (!placeData.closureStatus) {
      const fullText = element.textContent.toLowerCase();
      const closureKeywords = [
        'permanently closed',
        'temporarily closed',
        'closed for renovation',
        'closed for repairs',
        'closed until further notice',
        'business closed'
      ];

      for (const keyword of closureKeywords) {
        if (fullText.includes(keyword)) {
          if (keyword.includes('permanently')) {
            placeData.closureStatus = 'Permanently Closed';
          } else if (keyword.includes('temporarily') || keyword.includes('renovation') || keyword.includes('repairs') || keyword.includes('until further notice')) {
            placeData.closureStatus = 'Temporarily Closed';
          } else {
            placeData.closureStatus = 'Closed';
          }
          break;
        }
      }
    }

    return placeData;
  }

  setupPageChangeListener() {
    // Listen for navigation to next page
    const nextButton = document.querySelector('#pnnext, [aria-label="Next"]');
    if (nextButton) {
      nextButton.addEventListener('click', () => {
        if (this.isScrapingActive) {
          console.log('Next button clicked, will scrape new page...');
          setTimeout(async () => {
            await this.scrapeCurrentPage();
          }, 3000); // Wait longer for page to load
        }
      });
    }

    // Also listen for URL changes
    let currentUrl = window.location.href;
    setInterval(() => {
      if (this.isScrapingActive && window.location.href !== currentUrl) {
        currentUrl = window.location.href;
        console.log('URL changed, will scrape new page...');
        setTimeout(async () => {
          await this.scrapeCurrentPage();
        }, 3000); // Wait longer for page to load
      }
    }, 1000);
  }

  updateDataCount() {
    document.getElementById('data-count').textContent = `Items scraped: ${this.scrapedData.length}`;
  }

  exportData() {
    if (this.scrapedData.length === 0) {
      alert('No data to export. Please scrape some places first.');
      return;
    }

    const csvContent = this.convertToCSV(this.scrapedData);
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `google_places_data_${new Date().getTime()}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  }

  convertToCSV(data) {
    const headers = ['Place ID', 'Name', 'Address', 'Website', 'Phone', 'Email', 'Rating', 'Review Count', 'Business Type', 'Closure Status', 'Search Keyword', 'Google Location', 'Scraped At'];
    const csvRows = [headers.join(',')];

    data.forEach(place => {
      const row = [
        this.escapeCSV(place.id),
        this.escapeCSV(place.name),
        this.escapeCSV(place.address),
        this.escapeCSV(place.website),
        this.escapeCSV(place.phone),
        this.escapeCSV(place.email),
        this.escapeCSV(place.rating),
        this.escapeCSV(place.reviewCount),
        this.escapeCSV(place.businessType),
        this.escapeCSV(place.closureStatus),
        this.escapeCSV(place.searchKeyword),
        this.escapeCSV(place.googleLocation),
        this.escapeCSV(place.scrapedAt)
      ];
      csvRows.push(row.join(','));
    });

    return csvRows.join('\n');
  }

  escapeCSV(value) {
    if (value === null || value === undefined) return '';
    const stringValue = String(value);
    if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
      return `"${stringValue.replace(/"/g, '""')}"`;
    }
    return stringValue;
  }

  async clearData() {
    this.scrapedData = [];
    this.isScrapingActive = false;
    
    await chrome.storage.local.remove(['scrapedData', 'isScrapingActive']);
    this.updateDataCount();
    this.updateUIState();
    document.getElementById('scraping-status').textContent = 'Data cleared';
  }

  extractSearchKeyword() {
    try {
      const url = new URL(window.location.href);
      const searchParams = url.searchParams;
      
      // Try different parameter names that Google uses for search queries
      const possibleParams = ['q', 'query', 'search'];
      
      for (const param of possibleParams) {
        const keyword = searchParams.get(param);
        if (keyword) {
          return decodeURIComponent(keyword);
        }
      }
      
      // Fallback: try to extract from the URL path or hash
      const pathMatch = url.pathname.match(/\/search\/([^\/]+)/);
      if (pathMatch) {
        return decodeURIComponent(pathMatch[1]);
      }
      
      // If no keyword found, return empty string
      return '';
    } catch (error) {
      console.log('Error extracting search keyword:', error);
      return '';
    }
  }

  listenForMessages() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'getScrapeData') {
        sendResponse({ data: this.scrapedData });
      }
    });
  }
}

// Initialize the extractor when the page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', async () => {
    new GooglePlacesExtractor();
  });
} else {
  new GooglePlacesExtractor();
}