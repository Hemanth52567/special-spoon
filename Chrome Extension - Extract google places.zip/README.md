# Google Places Extractor Chrome Extension

A Chrome extension designed to extract place information from Google Places search results.

## Features

- 🗺️ Extracts place data from Google Places
- 📊 Extracts name, address, website, phone, email, ratings, and reviews
- 🔄 Automatically continues scraping when navigating to next pages
- 💾 Saves data locally in browser storage
- 📥 Export data as CSV file
- 🎯 Easy-to-use floating interface on Google search pages

## Installation

1. **Download the extension files**
   - Save all the files in a folder on your computer

2. **Enable Developer Mode in Chrome**
   - Open Chrome and go to `chrome://extensions/`
   - Toggle "Developer mode" in the top right corner

3. **Load the extension**
   - Click "Load unpacked" button
   - Select the folder containing the extension files
   - The extension should now appear in your extensions list

## Usage

1. **Search for places**
   - Go to Google (google.com)
   - Search for any places (e.g., "restaurants in New York", "hotels in Paris")
   - Click on the "Places" tab in the search results

2. **Start extracting**
   - You'll see a floating "Google Places Extractor" panel on the page
   - Click "Start Scraping" to begin collecting data
   - The extension will automatically extract visible places

3. **Navigate through pages**
   - Click "Next" to go to the next page of results
   - The extension will wait for the page to load and continue extracting
   - Keep navigating through all pages you want to extract

4. **Stop and export**
   - Click "Stop" when you've finished navigating all pages
   - Click "Export CSV" to download your extracted data
   - The CSV file will contain all collected information

## Data Collected

The extension collects the following information for each place:

- **Name**: Name of the place
- **Address**: Physical address (if available)
- **Website**: Official website URL (if available)
- **Phone**: Contact phone number (if available)
- **Email**: Contact email address (if available)
- **Rating**: Google rating (if available)
- **Reviews**: Review count (if available)
- **Google Location**: URL of the Google search results page
- **Scraped At**: Timestamp when the data was collected

## Extension Interface

### Floating Panel (on Google search pages)
- **Start Scraping**: Begin collecting data from current page
- **Stop**: Stop the scraping process
- **Export CSV**: Download collected data as CSV file
- **Clear Data**: Remove all collected data

### Popup Interface
- View scraped data count and status
- Preview recently scraped places
- Export data to CSV
- Clear all data
- Instructions for usage

## Tips for Best Results

1. **Use specific search terms**: Use specific location-based searches for best results
2. **Navigate slowly**: Allow pages to fully load before clicking next
3. **Check data regularly**: Use the popup to monitor progress
4. **Export frequently**: Save your data periodically to avoid loss

## Troubleshooting

- **Extension not working**: Make sure you're on a Google search page with Places results
- **No data collected**: Ensure you clicked "Start Scraping" before navigating
- **Missing information**: Some places may not have complete information available
- **Page not loading**: Wait a few seconds for pages to fully load before proceeding

## Privacy & Data

- All data is stored locally in your browser
- No data is sent to external servers
- Data is automatically cleaned up after one week
- You can clear data manually at any time

## Technical Details

- **Manifest Version**: 3 (latest Chrome extension standard)
- **Permissions**: Active tab, storage, scripting
- **Storage**: Chrome local storage
- **Export Format**: CSV (Comma Separated Values)

## Support

This extension is designed for extracting place information from Google Places search results. For best results, follow the usage instructions carefully and ensure you're on the correct Google search pages.

---

**Note**: This extension is for educational and research purposes. Please respect Google's terms of service and use responsibly. 