// Popup JavaScript for Google Places Extractor
document.addEventListener('DOMContentLoaded', function() {
    const itemCountElement = document.getElementById('item-count');
    const scrapingStatusElement = document.getElementById('scraping-status');
    const dataListElement = document.getElementById('data-list');
    const refreshButton = document.getElementById('refresh-data');
    const exportButton = document.getElementById('export-csv');
    const clearButton = document.getElementById('clear-all');

    let scrapedData = [];

    // Initialize popup
    init();

    function init() {
        loadStoredData();
        setupEventListeners();
    }

    function setupEventListeners() {
        refreshButton.addEventListener('click', loadStoredData);
        exportButton.addEventListener('click', exportToCSV);
        clearButton.addEventListener('click', clearAllData);
    }

    function loadStoredData() {
        chrome.storage.local.get(['scrapedData'], function(result) {
            scrapedData = result.scrapedData || [];
            updateUI();
        });
    }

    function updateUI() {
        itemCountElement.textContent = scrapedData.length;
        updateDataList();
        
        if (scrapedData.length > 0) {
            scrapingStatusElement.textContent = 'Data Available';
            exportButton.disabled = false;
        } else {
            scrapingStatusElement.textContent = 'No Data';
            exportButton.disabled = true;
        }
    }

    function updateDataList() {
        if (scrapedData.length === 0) {
            dataListElement.innerHTML = '<p class="no-data">No data available. Start scraping to see results.</p>';
            return;
        }

        const recentData = scrapedData.slice(-5); // Show last 5 items
        let html = '';

        recentData.forEach((place, index) => {
            html += `
                <div class="data-item">
                    <div class="place-name">${place.name || 'Unknown'}</div>
                    <div class="place-details">
                        ${place.searchKeyword ? `<div class="detail" style="font-size: 11px; color: #666;">🔍 ${place.searchKeyword}</div>` : ''}
                        ${place.id ? `<div class="detail" style="font-size: 10px; color: #999;">🆔 ${place.id}</div>` : ''}
                        ${place.businessType ? `<div class="detail">🏷️ ${place.businessType}</div>` : ''}
                        ${place.address ? `<div class="detail">📍 ${place.address}</div>` : ''}
                        ${place.phone ? `<div class="detail">📞 ${place.phone}</div>` : ''}
                        ${place.rating ? `<div class="detail">⭐ ${place.rating}${place.reviewCount ? ` (${place.reviewCount} reviews)` : ''}</div>` : ''}
                        ${place.closureStatus ? `<div class="detail">🚫 ${place.closureStatus}</div>` : ''}
                        ${place.website ? `<div class="detail">🌐 <a href="${place.website}" target="_blank">Website</a></div>` : ''}
                    </div>
                </div>
            `;
        });

        if (scrapedData.length > 5) {
            html += `<div class="more-items">... and ${scrapedData.length - 5} more items</div>`;
        }

        dataListElement.innerHTML = html;
    }

    function exportToCSV() {
        if (scrapedData.length === 0) {
            alert('No data to export. Please scrape some places first.');
            return;
        }

        const csvContent = convertToCSV(scrapedData);
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `google_places_data_${new Date().getTime()}.csv`;
        a.click();
        
        URL.revokeObjectURL(url);
    }

    function convertToCSV(data) {
        const headers = ['Place ID', 'Name', 'Address', 'Website', 'Phone', 'Email', 'Rating', 'Review Count', 'Business Type', 'Closure Status', 'Search Keyword', 'Google Location', 'Scraped At'];
        const csvRows = [headers.join(',')];

        data.forEach(place => {
            const row = [
                escapeCSV(place.id),
                escapeCSV(place.name),
                escapeCSV(place.address),
                escapeCSV(place.website),
                escapeCSV(place.phone),
                escapeCSV(place.email),
                escapeCSV(place.rating),
                escapeCSV(place.reviewCount),
                escapeCSV(place.businessType),
                escapeCSV(place.closureStatus),
                escapeCSV(place.searchKeyword),
                escapeCSV(place.googleLocation),
                escapeCSV(place.scrapedAt)
            ];
            csvRows.push(row.join(','));
        });

        return csvRows.join('\n');
    }

    function escapeCSV(value) {
        if (value === null || value === undefined) return '';
        const stringValue = String(value);
        if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
            return `"${stringValue.replace(/"/g, '""')}"`;
        }
        return stringValue;
    }

    function clearAllData() {
        if (confirm('Are you sure you want to clear all scraped data? This action cannot be undone.')) {
            chrome.storage.local.remove('scrapedData');
            scrapedData = [];
            updateUI();
            
            // Also send message to content script to clear data
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {action: 'clearData'});
            });
        }
    }

    // Listen for messages from content script
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        if (request.action === 'updatePopup') {
            loadStoredData();
        }
    });

    // Refresh data every 2 seconds if popup is open
    setInterval(loadStoredData, 2000);
}); 