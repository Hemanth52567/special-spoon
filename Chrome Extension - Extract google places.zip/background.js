// Background Service Worker for Google Places Extractor
chrome.runtime.onInstalled.addListener(() => {
    console.log('Google Places Extractor extension installed');
});

// Handle messages from content script and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'saveData') {
        // Save scraped data to storage
        chrome.storage.local.set({ scrapedData: request.data }, () => {
            sendResponse({ success: true });
        });
        return true; // Keep message channel open for async response
    }
    
    if (request.action === 'getData') {
        // Get scraped data from storage
        chrome.storage.local.get(['scrapedData'], (result) => {
            sendResponse({ data: result.scrapedData || [] });
        });
        return true; // Keep message channel open for async response
    }
    
    if (request.action === 'clearData') {
        // Clear all scraped data
        chrome.storage.local.remove('scrapedData', () => {
            sendResponse({ success: true });
        });
        return true; // Keep message channel open for async response
    }
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
    // Check if we're on a Google search page
    if (tab.url && tab.url.includes('google.com/search')) {
        // The popup will open automatically due to manifest configuration
        console.log('Extension clicked on Google search page');
    } else {
        // Show notification if not on Google search page
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon48.png',
            title: 'Google Places Extractor',
            message: 'Please navigate to Google search and search for places to use this extension.'
        });
    }
});

// Monitor tab updates to detect navigation
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes('google.com/search')) {
        // Inject content script if needed
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['content.js']
        }).catch(err => {
            // Script might already be injected, ignore error
            console.log('Content script injection:', err.message);
        });
    }
});

// Handle storage changes
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.scrapedData) {
        // Notify popup about data changes
        chrome.runtime.sendMessage({
            action: 'updatePopup',
            data: changes.scrapedData.newValue
        }).catch(() => {
            // Popup might not be open, ignore error
        });
    }
});

// Cleanup old data periodically (optional)
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'cleanup') {
        chrome.storage.local.get(['scrapedData'], (result) => {
            if (result.scrapedData) {
                const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
                const filteredData = result.scrapedData.filter(item => {
                    return new Date(item.scrapedAt) > oneWeekAgo;
                });
                
                if (filteredData.length !== result.scrapedData.length) {
                    chrome.storage.local.set({ scrapedData: filteredData });
                    console.log('Cleaned up old scraped data');
                }
            }
        });
    }
});

// Set up periodic cleanup (once per day)
chrome.alarms.create('cleanup', { delayInMinutes: 1440, periodInMinutes: 1440 }); 